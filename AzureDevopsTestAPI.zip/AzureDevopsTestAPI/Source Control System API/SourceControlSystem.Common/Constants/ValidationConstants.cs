﻿namespace SourceControlSystem.Common.Constants
{
    public class ValidationConstants
    {
        public const int MaxProjectName = 100;
        public const int MaxProjectDescription = 1000;
    }
}
