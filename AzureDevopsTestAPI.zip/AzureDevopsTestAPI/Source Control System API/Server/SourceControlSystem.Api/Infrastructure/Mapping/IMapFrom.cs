﻿namespace SourceControlSystem.Api.Infrastructure.Mapping
{
    public interface IMapFrom<TModel>
    {
    }
}
